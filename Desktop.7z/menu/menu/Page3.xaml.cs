﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace menu
{
    /// <summary>
    /// Interaction logic for Page3.xaml
    /// </summary>
    public partial class Page3 : Page
    {
        public List<Grade> _grade;

        public Page3()
        {
            InitializeComponent();
            _grade = new List<Grade>();
            _grade.Add(new Grade { ID = "8412", Result = "4" });
            _grade.Add(new Grade { ID = "8421", Result = "6" });
            _grade.Add(new Grade { ID = "8403", Result = "6" });
            _grade.Add(new Grade { ID = "8425", Result = "2" });
            _grade.Add(new Grade { ID = "8431", Result = "6" });
            _grade.Add(new Grade { ID = "8388", Result = "5" });
            _grade.Add(new Grade { ID = "8382", Result = "5" });
            _grade.Add(new Grade { ID = "8455", Result = "6" });
            _grade.Add(new Grade { ID = "8435", Result = "6" });
            _grade.Add(new Grade { ID = "8432", Result = "5" });


            dataGrid1.ItemsSource = _grade;
        }

        private void textBox1_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            var filtered = _grade.Where(grade => grade.ID.Contains(textBox1.Text));

            dataGrid1.ItemsSource = filtered;
        }
        private void textBox2_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            var filtered = _grade.Where(grade => grade.Result.Contains(textBox2.Text));

            dataGrid1.ItemsSource = filtered;
        }
    }

    public class Grade
    {
        public string ID { get; set; }
        public string Result { get; set; }
    }
}
