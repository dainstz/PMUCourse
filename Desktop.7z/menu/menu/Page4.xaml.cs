﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace menu
{
    /// <summary>
    /// Interaction logic for Page4.xaml
    /// </summary>
    public partial class Page4 : Page
    {
        private List<Grade> _grade;

        public Page4()
        {
            InitializeComponent();
            _grade = new List<Grade>();
            _grade.Add(new Grade { ID = "8412", Result = "4" });
            _grade.Add(new Grade { ID = "8421", Result = "6" });
            _grade.Add(new Grade { ID = "8403", Result = "6" });
            _grade.Add(new Grade { ID = "8425", Result = "2" });
            _grade.Add(new Grade { ID = "8431", Result = "6" });
            _grade.Add(new Grade { ID = "8388", Result = "5" });
            _grade.Add(new Grade { ID = "8382", Result = "5" });
            _grade.Add(new Grade { ID = "8455", Result = "6" });
            _grade.Add(new Grade { ID = "8435", Result = "6" });
            _grade.Add(new Grade { ID = "8432", Result = "5" });
            //_grade.Sort();
            // var ones = CountOccurenceOfValue(_grade, "2");
            //Console.WriteLine(ones);
            //var g=_grade.GroupBy(gra5de.I =>grade.ID);
            //int[] myNum = {10, 20, 30, 40};



            //dataGrid1.ItemsSource = _grade;
        }

        private void Tendention_Click_1(object sender, RoutedEventArgs e)
        {
            int two = 0, tree = 0, four = 0, five = 0, six = 0;
            int mostFrequent;
            foreach (Grade item in _grade) // Loop through List with foreach
            {
                if (item.Result == "2")
                {
                    two++;
                }
                if (item.Result == "3")
                {
                    tree++;
                }
                if (item.Result == "4")
                {
                    four++;
                }
                if (item.Result == "5")
                {
                    five++;
                }
                if (item.Result == "6")
                {
                    six++;
                }
            }
            int[] arr = { two, tree, four, five, six };
            mostFrequent = 0;
            string value = "0";
            for (int i = 0, j = 2; i <= 4; i++, j++)
            {
                if (mostFrequent < arr[i])
                {
                    mostFrequent = arr[i];
                    value = j.ToString();
                }

            }
            List<Analize> tendation;
            tendation = new List<Analize>();
            tendation.Add(new Analize { Number = mostFrequent, Result = "Most frequent:" + value });
            dataGrid1.ItemsSource = tendation;
            Debug.WriteLine("WTF1");
        }

        private void Frequency_Click(object sender, RoutedEventArgs e)
        {
            int two = 0, tree = 0, four = 0, five = 0, six = 0;
            foreach (Grade item in _grade) // Loop through List with foreach
            {
                if (item.Result == "2")
                {
                    two++;
                }
                if (item.Result == "3")
                {
                    tree++;
                }
                if (item.Result == "4")
                {
                    four++;
                }
                if (item.Result == "5")
                {
                    five++;
                }
                if (item.Result == "6")
                {
                    six++;
                }
            }
            List<Analize> frequency;
            frequency = new List<Analize>();
            frequency.Add(new Analize { Number = two, Result = "2" });
            frequency.Add(new Analize { Number = tree, Result = "3" });
            frequency.Add(new Analize { Number = four, Result = "4" });
            frequency.Add(new Analize { Number = five, Result = "5" });
            frequency.Add(new Analize { Number = six, Result = "6" });
            dataGrid1.ItemsSource = frequency;
            Console.WriteLine(two);
            Console.WriteLine(six);
            Debug.WriteLine("WTF2");
        }

        private void Razmah_Click(object sender, RoutedEventArgs e)
        {
            int smallest = Int32.Parse(_grade[0].Result), bigest = 0;
            string smallID = null, bigID = null;

            foreach (Grade item in _grade) // Loop through List with foreach
            {
                if (bigest < Int32.Parse(item.Result))
                {
                    bigest = Int32.Parse(item.Result);
                    bigID = String.Copy(item.ID);
                }
                if (smallest > Int32.Parse(item.Result))
                {
                    smallest = Int32.Parse(item.Result);
                    smallID = String.Copy(item.ID);
                }
            }
            List<Analize> razmah;
            razmah = new List<Analize>();
            razmah.Add(new Analize { Number = smallest, Result = smallID });
            razmah.Add(new Analize { Number = bigest, Result = bigID });
            razmah.Add(new Analize { Number = bigest - smallest, Result = "Razmah" });



            dataGrid1.ItemsSource = razmah;

        }

    }

    public class Analize
    {
        public string Result { get; set; }
        public int Number { get; set; }

    }

}