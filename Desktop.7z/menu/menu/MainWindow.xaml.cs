﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace menu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Page1 page1 = new Page1();
        Page2 page2 = new Page2();
        Page3 page3 = new Page3();
        Page4 page4 = new Page4();

        Color color1 = Color.FromRgb(237, 246, 253);
        Color color2 = Color.FromRgb(226, 67, 67);

        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Content = page1;
            page1_btn.Background = new SolidColorBrush(color1);
        }

        private void QuitBtn_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(1);
        }

        private void MinmzBtn_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void page1_btn_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = page1;
            page1_btn.Background = new SolidColorBrush(color1);
            page2_btn.Background = new SolidColorBrush(color2);
            page3_btn.Background = new SolidColorBrush(color2);
            page4_btn.Background = new SolidColorBrush(color2);
        }

        private void page2_btn_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = page2;
            page1_btn.Background = new SolidColorBrush(color2);
            page2_btn.Background = new SolidColorBrush(color1);
            page3_btn.Background = new SolidColorBrush(color2);
            page4_btn.Background = new SolidColorBrush(color2);
        }

        private void page3_btn_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = page3;
            page1_btn.Background = new SolidColorBrush(color2);
            page2_btn.Background = new SolidColorBrush(color2);
            page3_btn.Background = new SolidColorBrush(color1);
            page4_btn.Background = new SolidColorBrush(color2);
        }

        private void page4_btn_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = page4;
            page1_btn.Background = new SolidColorBrush(color2);
            page2_btn.Background = new SolidColorBrush(color2);
            page3_btn.Background = new SolidColorBrush(color2);
            page4_btn.Background = new SolidColorBrush(color1);
        }
    }
}
